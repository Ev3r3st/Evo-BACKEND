import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }

  getAppInfo(): { name: string; version: string } {
    return {
      name: 'My Awesome App',
      version: '1.0.0', // Můžete načíst dynamicky z env nebo package.json
    };
  }
}
